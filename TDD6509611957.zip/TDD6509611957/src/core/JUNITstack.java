package core;

import junit.framework.TestCase;

public class JUNITstack extends TestCase {
	
	public void testCreateNewEmptyStack() {
		
		Stack s1 = new Stack();
		int size = s1.getSize();
		
		assertEquals(0, size);
		assertTrue(s1.isEmpty());
	}
        
	public void pushElmToTop() {
		Stack s2 = new Stack();
		s2.push(1);
		assertEquals(1, s2.top());
	}
  
} 

package core;

public class Stack implements IStack {
	Object[] stack = new Object[10];
	int size = 0;
	int top = -1;
	
	public boolean isFull() {
        return top == 9;
    }
     
	@Override 
	public boolean isEmpty() {
		return size == 0;
	}
 
	@Override
	public int getSize() {
		return size;
	}
	 
	public void push(Object elm) { 
		if(!isFull()) {
			stack[top] = elm;
			top++;
		}
    }
	
	public Object top() {
		return stack[top];
	}

}
